# UWPEcho.Client

This example connects to the Echo.Server with SSL, using the StreamSocketChannel class